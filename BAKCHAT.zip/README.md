﻿main readme ------> [README.md](./README/README.md)\
code of conduct --> [CODE_OF_CONDUCT.md](./README/CODE_OF_CONDUCT.md)\
license ------------> [LICENSE.md](./README/LICENSE.md)\# BakChat
# 



