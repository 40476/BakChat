﻿main readme ------> [README.md](./README/README.md)\
code of conduct --> [CODE_OF_CONDUCT.md](./README/CODE_OF_CONDUCT.md)\
license ------------> [LICENSE.md](./README/LICENSE.md)\
# THERE ARE A BAZILLION BROKEN OR UN-IMPLEMENTED FEATURES IN THIS PROGRAM IT WOULD BE GREATLY HELPFUL IF OSMEONE COULD FIX SOME

# I will put you in the credits



<!-- * online/offline status -->
* kick (needs to be server-side)
* ban/unban (needs to be server-side)
* slience this weird goofy error when viwing profile info (see console while spamming reload)
* profile editor (functality needed)
* sitewide login system
* better cross-server chatting (like minecraft<-->discord)
* plugins
* server management gui
* account management gui
* parental controls
* setup wizard
* tutorial
* bots
* better chat filter
* user groups for companies and school districts
* system for friending/unfriending people
* see peoples friends on the profile page
* favorite room on profile page
* room creation dialog
