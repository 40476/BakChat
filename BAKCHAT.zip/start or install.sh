﻿#!/bin/bash
echo "PLEASE CHECK AND UPDATE YOUR 'SCONFIG.JSON' IT MIGHT CONTAIN INCORRECT SETTINGS"

# mkdir bakchat
# cd bakchat

# sudo systemctl enable ssh
# sudo systemctl start ssh
sleep 10
rm BAKCHAT.zip
wait -n
wget https://github.com/40476/BakChat/raw/main/BAKCHAT.zip
wait -n
unzip -o BAKCHAT.zip
wait -n
# npm install
npm start