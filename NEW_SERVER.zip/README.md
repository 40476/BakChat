﻿main readme ------> [README.md](./README/README.md)\
code of conduct --> [CODE_OF_CONDUCT.md](./README/CODE_OF_CONDUCT.md)\
license ------------> [LICENSE.md](./README/LICENSE.md)\
# THERE ARE A BAZILLION BROKEN OR UN-IMPLEMENTED FEATURES IN THIS PROGRAM IT WOULD BE GREATLY HELPFUL IF SOMEONE COULD FIX IMPLEMENT SOME OF THESE

# I will put you in the credits



<!-- * online/offline status -->
* `kick (needs to be server-side)=======================================(HIGH PRIORITY)`
* `ban/unban (needs to be server-side)----------------------------------(HIGH PRIORITY)`
* `slience this weird goofy error when viwing profile info (see console while spamming reload)`
* `profile editor (functality needed)=====================(IN PROGRESS) (HIGH PRIORITY)`
* `sitewide login system--------------------------------(IN PROGRESS) (MEDIUM PRIORITY)`
* `better cross-server chatting (like minecraft<-->discord)==============(LOW PRIORITY)`
* `plugins -----------------------------------------------------------(MEDIUM PRIORITY)`
* `server management gui==============================================(MEDIUM PRIORITY)`
* `account management gui---------------------------------------------(MEDIUM PRIORITY)`
* `parental controls=====================================================(LOW PRIORITY)`
* `setup wizard----------------------------------------------------------(LOW PRIORITY)`
* `tutorial==============================================================(LOW PRIORITY)`
* `bots------------------------------------------------------------------(LOW PRIORITY)`
* `better chat filter====================================================(LOW PRIORITY)`
* `user groups for companies and school districts-----------------------(HIGH PRIORITY)`
* `system for friending/unfriending people===============================(LOW PRIORITY)`
* `see peoples friends on the profile page-------------------------------(LOW PRIORITY)`
* `favorite room on profile page=========================================(LOW PRIORITY)`
* `room creation dialog-------------------------------------------------(HIGH PRIORITY)`
