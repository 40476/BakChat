makeFolder('./users');
makeFolder('./chatlogs');